#pragma once
//#include "stdafx.h"

namespace usr::util::inject
{
	//remote thread inject
	//apc inject
	//thread context inject
	//nt inject for native process
}