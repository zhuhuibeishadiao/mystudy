#pragma once
//#include "stdafx.h"
#include "util.h"
#include "snapshot_process.h"
#include "Process.h"
#include "Memory.h"
#include "inject.h"
#include "Services.h"

//����
#define ASIO_STRANDALONE
#include "asio.hpp"
#include "pkg_msg.h"
#include "client.h"
#include "server.h"

#include "lsp_helper.h"