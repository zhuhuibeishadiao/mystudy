#pragma once
#include "stdafx.h"

__declspec(dllexport) void abcd();
__declspec(dllexport) void abcd(int i);