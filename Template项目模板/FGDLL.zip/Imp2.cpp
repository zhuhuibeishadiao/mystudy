#include "stdafx.h"
#include <stdio.h>

void abcd(int i)
{
	printf("cao cao %d\n", i);
}