#pragma once
#include "stdafx.h"

void abc();
void abcd();
